# Starter Project — Golang + React

Boilerplate full-stack dengan autentikasi JWT siap pakai.

## Tech Stack
- **Backend:** Golang, Gin, GORM, PostgreSQL, JWT
- **Frontend:** React (Vite), React Router, Axios, Context API

## Struktur
```
backend/    -> REST API (Golang)
frontend/   -> Web app (React)
```

## Cara Menjalankan

### 1. Backend
```bash
cd backend
cp .env.example .env    # sesuaikan konfigurasi database
go mod tidy
go run cmd/api/main.go
```
Backend jalan di `http://localhost:8080`

### 2. Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```
Frontend jalan di `http://localhost:5173`

## Fitur yang sudah tersedia
- Register & Login dengan JWT
- Password hashing (bcrypt)
- Middleware auth untuk proteksi endpoint
- Protected route di sisi frontend
- API layer terpisah dengan axios interceptor
- Struktur folder scalable (layered architecture di backend)

## Langkah selanjutnya (saran)
- Tambah validasi input lebih ketat
- Tambah refresh token
- Tambah role/permission (admin, user, dll)
- Setup migration file terpisah (bukan auto-migrate) untuk production
- Tambah unit test
- Setup CI/CD (GitHub Actions, dll)

Lihat README di masing-masing folder (`backend/README.md` dan `frontend/README.md`) untuk detail lebih lanjut.
