# Starter Project (Hardened) — Golang + React

Versi ini adalah pengembangan dari boilerplate dasar, dengan tambahan praktik
keamanan yang relevan untuk sistem yang menyimpan data sensitif (misalnya
sistem internal instansi pemerintah).

## Apa yang Berbeda dari Versi Dasar?

### 1. Token disimpan di httpOnly Cookie, bukan localStorage
- Backend (`user_handler.go`) sekarang set cookie `access_token` dengan flag
  `httpOnly: true`, sehingga **tidak bisa dibaca oleh JavaScript** di browser.
- Ini menutup celah pencurian token lewat serangan **XSS** — bahkan kalau ada
  script jahat berhasil ter-inject, dia tidak bisa mengambil token.
- Konsekuensinya, frontend tidak lagi menerima token di response body. Status
  login dicek lewat endpoint `GET /api/auth/me`.

### 2. Security Headers (`security_headers.go`)
Setiap response otomatis menyertakan header:
- `Content-Security-Policy` — membatasi sumber script/style/gambar yang boleh
  dimuat, mencegah script asing ter-eksekusi.
- `X-Frame-Options: DENY` — mencegah halaman di-embed di iframe (anti-clickjacking).
- `X-Content-Type-Options: nosniff` — mencegah browser "menebak" tipe file.
- `Strict-Transport-Security` — paksa browser selalu pakai HTTPS.
- `Referrer-Policy`, `Permissions-Policy` — mengurangi kebocoran informasi.

### 3. Rate Limiting di Endpoint Login (`rate_limiter.go`)
- Membatasi jumlah percobaan login per alamat IP per menit (default: 5).
- Mencegah serangan **brute-force** password.
- Konfigurasi lewat `LOGIN_RATE_LIMIT` di `.env`.

### 4. CORS Ketat
- Origin diatur eksplisit lewat `ALLOWED_ORIGIN` (bukan wildcard `*`).
- `AllowCredentials: true` diperlukan agar cookie ikut terkirim lintas origin
  saat development (frontend di port berbeda dari backend).

### 5. Pesan Error Digeneralisir (Anti-Enumeration)
- Login gagal karena email salah atau password salah, keduanya menampilkan
  pesan yang sama: `"email atau password salah"`.
- Ini mencegah penyerang menebak-nebak email mana saja yang terdaftar di sistem.

### 6. Password Minimum Diperketat
- Minimal 8 karakter (dari sebelumnya 6) di validasi register.
- Untuk sistem sensitif, pertimbangkan menambah aturan kompleksitas (kombinasi
  huruf besar/kecil, angka, simbol) sesuai kebijakan instansi.

### 7. Fail-Fast di Production
- `main.go` akan menolak start kalau `APP_ENV=production` tapi `JWT_SECRET`
  masih nilai default `"secret"` — mencegah deploy dengan secret lemah karena lupa diganti.

## Yang Masih Perlu Kamu Lakukan Sebelum Production

Boilerplate ini adalah **titik awal**, bukan solusi lengkap. Sebelum dipakai
untuk sistem sungguhan (apalagi instansi pemerintah), pastikan juga:

- [ ] **HTTPS wajib** — set `COOKIE_SECURE=true` dan pastikan server di
      belakang TLS/reverse proxy (nginx/Caddy) dengan sertifikat valid.
- [ ] **Audit trail** — catat setiap aksi penting (login, ubah data, hapus
      data) ke tabel log terpisah, termasuk siapa & kapan.
- [ ] **MFA (Multi-Factor Authentication)** untuk akun admin/pegawai.
- [ ] **RBAC granular** — role & permission per-modul, bukan cuma admin/user.
- [ ] **Dependency scanning** — jalankan `govulncheck` (Go) dan `npm audit`
      (frontend) secara rutin.
- [ ] **Penetration testing** oleh pihak independen sebelum go-live.
- [ ] **Backup & disaster recovery plan**.
- [ ] Sesuaikan `Content-Security-Policy` di `security_headers.go` bila kamu
      menambah CDN eksternal, font, atau layanan pihak ketiga.
- [ ] Tinjau kepatuhan terhadap **UU PDP** dan regulasi BSSN/Kominfo yang berlaku.

## Cara Menjalankan

Sama seperti versi dasar:

```bash
# Backend
cd backend
cp .env.example .env   # sesuaikan, terutama JWT_SECRET dan ALLOWED_ORIGIN
go mod tidy
go run cmd/api/main.go

# Frontend
cd frontend
cp .env.example .env
npm install
npm run dev
```

## Endpoint yang Tersedia

| Method | Endpoint             | Auth | Keterangan                          |
|--------|-----------------------|------|--------------------------------------|
| GET    | /api/health           | ❌   | Cek server hidup                     |
| POST   | /api/auth/register    | ❌   | Registrasi user baru                 |
| POST   | /api/auth/login       | ❌ * | Login, set httpOnly cookie (*rate-limited) |
| POST   | /api/auth/logout      | ❌   | Hapus cookie sesi                    |
| GET    | /api/auth/me          | ✅   | Cek status login & data user saat ini |
| GET    | /api/users            | ✅   | List semua user                      |

Tidak ada lagi header `Authorization: Bearer <token>` — otentikasi sepenuhnya
lewat cookie yang otomatis dikirim browser (`withCredentials: true` di axios).
