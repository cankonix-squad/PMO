# Backend — Golang Starter

Boilerplate REST API menggunakan Gin + GORM + PostgreSQL + JWT Auth.

## Struktur
```
cmd/api/main.go        -> entry point
internal/config        -> load environment config
internal/database      -> koneksi database
internal/models        -> struct/model database
internal/repository    -> query ke database
internal/service       -> business logic
internal/handler       -> controller (terima request, kirim response)
internal/middleware    -> auth & logger middleware
internal/router        -> definisi route
internal/utils         -> helper (JWT, response format)
```

## Setup

1. Copy environment file:
   ```
   cp .env.example .env
   ```
   Lalu sesuaikan `DB_*` dan `JWT_SECRET` dengan setup PostgreSQL kamu.

2. Pastikan PostgreSQL sudah jalan dan database sudah dibuat:
   ```sql
   CREATE DATABASE starter_db;
   ```

3. Download dependency:
   ```
   go mod tidy
   ```

4. Jalankan server:
   ```
   go run cmd/api/main.go
   ```

Server akan jalan di `http://localhost:8080`.

## Endpoint yang tersedia

| Method | Endpoint             | Auth | Deskripsi              |
|--------|----------------------|------|-------------------------|
| GET    | /api/health          | ❌   | Cek server hidup        |
| POST   | /api/auth/register   | ❌   | Registrasi user baru    |
| POST   | /api/auth/login      | ❌   | Login, dapat JWT token  |
| GET    | /api/users           | ✅   | List semua user         |

Untuk endpoint yang butuh auth, sertakan header:
```
Authorization: Bearer <token>
```

## Contoh request

**Register**
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","password":"secret123"}'
```

**Login**
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"secret123"}'
```

## Catatan
- Auto-migration aktif untuk kemudahan development (lihat `internal/database/database.go`). Untuk production, sebaiknya gunakan migration file terpisah di folder `migrations/`.
- Ganti `JWT_SECRET` dengan string acak yang panjang sebelum deploy ke production.
