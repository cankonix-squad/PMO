package main

import (
	"log"
	"strconv"

	"backend/internal/config"
	"backend/internal/database"
	"backend/internal/handler"
	"backend/internal/middleware"
	"backend/internal/repository"
	"backend/internal/router"
	"backend/internal/service"
)

func main() {
	cfg := config.Load()

	if cfg.AppEnv == "production" && cfg.JWTSecret == "secret" {
		log.Fatal("JWT_SECRET belum diganti dari default, wajib diisi secret yang kuat sebelum production")
	}

	db := database.Connect(cfg)

	userRepo := repository.NewUserRepository(db)
	userService := service.NewUserService(userRepo, cfg.JWTSecret, cfg.JWTExpireHours)
	userHandler := handler.NewUserHandler(userService, cfg)

	rateLimit, err := strconv.Atoi(cfg.LoginRateLimit)
	if err != nil {
		rateLimit = 5
	}
	loginLimiter := middleware.NewIPRateLimiter(rateLimit)

	r := router.Setup(cfg, userHandler, loginLimiter)

	log.Printf("server running on port %s (env: %s)", cfg.AppPort, cfg.AppEnv)
	if err := r.Run(":" + cfg.AppPort); err != nil {
		log.Fatalf("failed to start server: %v", err)
	}
}
