module backend

go 1.22

require (
	github.com/gin-contrib/cors v1.7.2
	github.com/gin-gonic/gin v1.10.0
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/joho/godotenv v1.5.1
	golang.org/x/crypto v0.24.0
	golang.org/x/time v0.5.0
	gorm.io/driver/postgres v1.5.9
	gorm.io/gorm v1.25.10
)
