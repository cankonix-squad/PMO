package config

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

type Config struct {
	AppPort         string
	AppEnv          string
	DBHost          string
	DBPort          string
	DBUser          string
	DBPassword      string
	DBName          string
	DBSSLMode       string
	JWTSecret       string
	JWTExpireHours  string
	CookieDomain    string
	CookieSecure    bool
	AllowedOrigin   string
	LoginRateLimit  string
}

func Load() *Config {
	if err := godotenv.Load(); err != nil {
		log.Println("no .env file found, using system environment variables")
	}

	return &Config{
		AppPort:        getEnv("APP_PORT", "8080"),
		AppEnv:         getEnv("APP_ENV", "development"),
		DBHost:         getEnv("DB_HOST", "localhost"),
		DBPort:         getEnv("DB_PORT", "5432"),
		DBUser:         getEnv("DB_USER", "postgres"),
		DBPassword:     getEnv("DB_PASSWORD", "postgres"),
		DBName:         getEnv("DB_NAME", "starter_db"),
		DBSSLMode:      getEnv("DB_SSLMODE", "disable"),
		JWTSecret:      getEnv("JWT_SECRET", "secret"),
		JWTExpireHours: getEnv("JWT_EXPIRE_HOURS", "8"),
		CookieDomain:   getEnv("COOKIE_DOMAIN", "localhost"),
		CookieSecure:   getEnv("COOKIE_SECURE", "false") == "true",
		AllowedOrigin:  getEnv("ALLOWED_ORIGIN", "http://localhost:5173"),
		LoginRateLimit: getEnv("LOGIN_RATE_LIMIT", "5"),
	}
}

func getEnv(key, fallback string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return fallback
}
