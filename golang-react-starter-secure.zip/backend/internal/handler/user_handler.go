package handler

import (
	"net/http"

	"backend/internal/config"
	"backend/internal/middleware"
	"backend/internal/service"
	"backend/internal/utils"

	"github.com/gin-gonic/gin"
)

type UserHandler struct {
	service *service.UserService
	cfg     *config.Config
}

func NewUserHandler(service *service.UserService, cfg *config.Config) *UserHandler {
	return &UserHandler{service: service, cfg: cfg}
}

type registerRequest struct {
	Name     string `json:"name" binding:"required"`
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required,min=8"`
}

type loginRequest struct {
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required"`
}

func (h *UserHandler) Register(c *gin.Context) {
	var req registerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	user, err := h.service.Register(req.Name, req.Email, req.Password)
	if err != nil {
		// Pesan generik, jangan bocorkan detail internal (misalnya "email sudah terdaftar")
		// yang bisa dipakai penyerang untuk enumerasi akun.
		utils.Error(c, http.StatusBadRequest, "registrasi gagal, periksa kembali data yang dimasukkan")
		return
	}

	utils.Success(c, http.StatusCreated, "registrasi berhasil", gin.H{
		"id":    user.ID,
		"name":  user.Name,
		"email": user.Email,
	})
}

func (h *UserHandler) Login(c *gin.Context) {
	var req loginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	token, expireHours, err := h.service.Login(req.Email, req.Password)
	if err != nil {
		// Pesan generik untuk email salah maupun password salah,
		// supaya penyerang tidak bisa membedakan mana yang salah (enumeration attack).
		utils.Error(c, http.StatusUnauthorized, "email atau password salah")
		return
	}

	maxAge := expireHours * 3600
	c.SetSameSite(http.SameSiteStrictMode)
	c.SetCookie(
		middleware.AuthCookieName,
		token,
		maxAge,
		"/",
		h.cfg.CookieDomain,
		h.cfg.CookieSecure, // true di production (wajib HTTPS)
		true,               // httpOnly -> tidak bisa diakses JavaScript di browser
	)

	utils.Success(c, http.StatusOK, "login berhasil", nil)
}

func (h *UserHandler) Logout(c *gin.Context) {
	c.SetSameSite(http.SameSiteStrictMode)
	c.SetCookie(
		middleware.AuthCookieName,
		"",
		-1,
		"/",
		h.cfg.CookieDomain,
		h.cfg.CookieSecure,
		true,
	)

	utils.Success(c, http.StatusOK, "logout berhasil", nil)
}

// Me mengembalikan info user yang sedang login, dipakai frontend untuk
// mengecek status auth saat pertama kali load aplikasi (karena token tidak
// lagi bisa dibaca dari localStorage/JavaScript).
func (h *UserHandler) Me(c *gin.Context) {
	userIDRaw, exists := c.Get("user_id")
	if !exists {
		utils.Error(c, http.StatusUnauthorized, "tidak terautentikasi")
		return
	}

	userID := uint(userIDRaw.(float64))
	user, err := h.service.GetByID(userID)
	if err != nil {
		utils.Error(c, http.StatusNotFound, "user tidak ditemukan")
		return
	}

	utils.Success(c, http.StatusOK, "ok", gin.H{
		"id":    user.ID,
		"name":  user.Name,
		"email": user.Email,
	})
}

func (h *UserHandler) GetUsers(c *gin.Context) {
	users, err := h.service.GetAllUsers()
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, "gagal mengambil data user")
		return
	}

	utils.Success(c, http.StatusOK, "berhasil mengambil data user", users)
}

