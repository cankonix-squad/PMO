package middleware

import (
	"net/http"

	"backend/internal/utils"

	"github.com/gin-gonic/gin"
)

const AuthCookieName = "access_token"

// AuthMiddleware membaca token dari httpOnly cookie (bukan header Authorization).
// Pendekatan ini mencegah JavaScript di browser mengakses token secara langsung,
// sehingga lebih tahan terhadap serangan XSS dibanding menyimpan token di localStorage.
func AuthMiddleware(jwtSecret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString, err := c.Cookie(AuthCookieName)
		if err != nil || tokenString == "" {
			utils.Error(c, http.StatusUnauthorized, "sesi tidak ditemukan, silakan login kembali")
			c.Abort()
			return
		}

		claims, err := utils.ParseToken(tokenString, jwtSecret)
		if err != nil {
			utils.Error(c, http.StatusUnauthorized, "sesi tidak valid atau kedaluwarsa")
			c.Abort()
			return
		}

		c.Set("user_id", claims["user_id"])
		c.Next()
	}
}
