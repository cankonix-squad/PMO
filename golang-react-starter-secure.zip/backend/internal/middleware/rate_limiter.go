package middleware

import (
	"net/http"
	"sync"
	"time"

	"backend/internal/utils"

	"github.com/gin-gonic/gin"
	"golang.org/x/time/rate"
)

// visitor menyimpan rate limiter dan waktu terakhir diakses untuk satu IP.
type visitor struct {
	limiter  *rate.Limiter
	lastSeen time.Time
}

type IPRateLimiter struct {
	visitors map[string]*visitor
	mu       sync.Mutex
	rps      rate.Limit
	burst    int
}

// NewIPRateLimiter membuat rate limiter baru. requestsPerMinute menentukan
// berapa banyak percobaan yang diizinkan per menit per alamat IP.
func NewIPRateLimiter(requestsPerMinute int) *IPRateLimiter {
	limiter := &IPRateLimiter{
		visitors: make(map[string]*visitor),
		rps:      rate.Every(time.Minute / time.Duration(requestsPerMinute)),
		burst:    requestsPerMinute,
	}

	go limiter.cleanupStale()

	return limiter
}

func (l *IPRateLimiter) getLimiter(ip string) *rate.Limiter {
	l.mu.Lock()
	defer l.mu.Unlock()

	v, exists := l.visitors[ip]
	if !exists {
		newLimiter := rate.NewLimiter(l.rps, l.burst)
		l.visitors[ip] = &visitor{limiter: newLimiter, lastSeen: time.Now()}
		return newLimiter
	}

	v.lastSeen = time.Now()
	return v.limiter
}

// cleanupStale membersihkan entry IP yang sudah lama tidak aktif agar memori tidak bocor.
func (l *IPRateLimiter) cleanupStale() {
	for {
		time.Sleep(time.Minute)
		l.mu.Lock()
		for ip, v := range l.visitors {
			if time.Since(v.lastSeen) > 3*time.Minute {
				delete(l.visitors, ip)
			}
		}
		l.mu.Unlock()
	}
}

// Limit mengembalikan gin middleware yang membatasi jumlah request per IP.
// Cocok dipasang di endpoint sensitif seperti /login untuk mencegah brute-force.
func (l *IPRateLimiter) Limit() gin.HandlerFunc {
	return func(c *gin.Context) {
		ip := c.ClientIP()
		limiter := l.getLimiter(ip)

		if !limiter.Allow() {
			utils.Error(c, http.StatusTooManyRequests, "terlalu banyak percobaan, coba lagi nanti")
			c.Abort()
			return
		}

		c.Next()
	}
}
