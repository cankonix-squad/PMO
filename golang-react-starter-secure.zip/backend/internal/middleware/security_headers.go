package middleware

import "github.com/gin-gonic/gin"

// SecurityHeaders menambahkan header keamanan standar untuk melindungi dari
// clickjacking, MIME sniffing, dan beberapa serangan umum lainnya.
func SecurityHeaders() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("X-Content-Type-Options", "nosniff")
		c.Header("X-Frame-Options", "DENY")
		c.Header("X-XSS-Protection", "1; mode=block")
		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")
		c.Header("Permissions-Policy", "geolocation=(), microphone=(), camera=()")

		// HSTS: paksa browser selalu pakai HTTPS setelah kunjungan pertama.
		// Hanya aktifkan di production dengan HTTPS yang valid.
		c.Header("Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload")

		// CSP dasar — sesuaikan domain sesuai kebutuhan asset/API kamu.
		c.Header("Content-Security-Policy",
			"default-src 'self'; "+
				"script-src 'self'; "+
				"style-src 'self' 'unsafe-inline'; "+
				"img-src 'self' data:; "+
				"connect-src 'self'; "+
				"frame-ancestors 'none'; "+
				"base-uri 'self'; "+
				"form-action 'self'",
		)

		c.Next()
	}
}
