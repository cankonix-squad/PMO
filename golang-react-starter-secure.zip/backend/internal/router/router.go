package router

import (
	"backend/internal/config"
	"backend/internal/handler"
	"backend/internal/middleware"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func Setup(cfg *config.Config, userHandler *handler.UserHandler, loginLimiter *middleware.IPRateLimiter) *gin.Engine {
	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(middleware.LoggerMiddleware())
	r.Use(middleware.SecurityHeaders())

	// CORS ketat: origin spesifik (bukan wildcard "*") dan izinkan credentials,
	// karena kita mengandalkan cookie untuk membawa sesi login.
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{cfg.AllowedOrigin},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Content-Type", "Authorization"},
		AllowCredentials: true,
	}))

	api := r.Group("/api")
	{
		api.GET("/health", func(c *gin.Context) {
			c.JSON(200, gin.H{"status": "ok"})
		})

		auth := api.Group("/auth")
		{
			auth.POST("/register", userHandler.Register)
			// Rate limit khusus di endpoint login untuk mencegah brute-force password.
			auth.POST("/login", loginLimiter.Limit(), userHandler.Login)
			auth.POST("/logout", userHandler.Logout)
			auth.GET("/me", middleware.AuthMiddleware(cfg.JWTSecret), userHandler.Me)
		}

		users := api.Group("/users")
		users.Use(middleware.AuthMiddleware(cfg.JWTSecret))
		{
			users.GET("", userHandler.GetUsers)
		}
	}

	return r
}
