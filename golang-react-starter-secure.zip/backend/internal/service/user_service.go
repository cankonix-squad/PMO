package service

import (
	"errors"
	"strconv"

	"backend/internal/models"
	"backend/internal/repository"
	"backend/internal/utils"

	"golang.org/x/crypto/bcrypt"
)

type UserService struct {
	repo           *repository.UserRepository
	jwtSecret      string
	jwtExpireHours string
}

func NewUserService(repo *repository.UserRepository, jwtSecret string, jwtExpireHours string) *UserService {
	return &UserService{repo: repo, jwtSecret: jwtSecret, jwtExpireHours: jwtExpireHours}
}

func (s *UserService) Register(name, email, password string) (*models.User, error) {
	// Cek duplikasi email lebih dulu supaya error bisa ditangani rapi
	// (pesan ke user tetap digeneralisir di handler untuk mencegah enumeration).
	if _, err := s.repo.FindByEmail(email); err == nil {
		return nil, errors.New("email sudah terdaftar")
	}

	hashed, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	user := &models.User{
		Name:     name,
		Email:    email,
		Password: string(hashed),
	}

	if err := s.repo.Create(user); err != nil {
		return nil, err
	}

	return user, nil
}

// Login mengembalikan token JWT beserta masa berlakunya dalam jam.
func (s *UserService) Login(email, password string) (string, int, error) {
	user, err := s.repo.FindByEmail(email)
	if err != nil {
		return "", 0, errors.New("invalid email or password")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return "", 0, errors.New("invalid email or password")
	}

	token, err := utils.GenerateToken(user.ID, s.jwtSecret, s.jwtExpireHours)
	if err != nil {
		return "", 0, err
	}

	hours, err := strconv.Atoi(s.jwtExpireHours)
	if err != nil {
		hours = 8
	}

	return token, hours, nil
}

func (s *UserService) GetByID(id uint) (*models.User, error) {
	return s.repo.FindByID(id)
}

func (s *UserService) GetAllUsers() ([]models.User, error) {
	return s.repo.FindAll()
}
