# Frontend — React Starter

Boilerplate React (Vite) dengan React Router, Axios, dan Context API untuk auth.

## Setup

1. Copy environment file:
   ```
   cp .env.example .env
   ```
   Sesuaikan `VITE_API_URL` dengan URL backend kamu.

2. Install dependency:
   ```
   npm install
   ```

3. Jalankan dev server:
   ```
   npm run dev
   ```

App akan jalan di `http://localhost:5173`.

## Struktur
```
src/components/ui       -> komponen dasar (Button, Input)
src/components/layout   -> layout (Header, dst)
src/pages               -> halaman per fitur
src/routes              -> definisi route & proteksi halaman
src/services            -> pemanggilan API ke backend
src/context             -> state auth global
src/hooks               -> custom hook (useAuth)
```

## Alur autentikasi
1. User isi form di halaman `Login`
2. `authService.js` memanggil endpoint `/api/auth/login` di backend
3. Token JWT disimpan di `localStorage` lewat `AuthContext`
4. Setiap request API otomatis menyertakan token lewat interceptor di `services/api.js`
5. Halaman yang butuh login dibungkus `ProtectedRoute` — otomatis redirect ke `/login` kalau belum login

## Menambah halaman baru
1. Buat folder baru di `src/pages/NamaHalaman/NamaHalaman.jsx`
2. Tambahkan route-nya di `src/routes/AppRoutes.jsx`
3. Kalau butuh data dari backend, buat file baru di `src/services/`

## Catatan
- Pastikan backend Golang sudah jalan dulu (default `http://localhost:8080`) sebelum test login.
