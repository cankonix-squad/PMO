import { useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";

export default function Header() {
  const { logout, isAuthenticated, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <header
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "16px 24px",
        background: "#fff",
        borderBottom: "1px solid #e5e7eb",
      }}
    >
      <strong>Starter App</strong>
      {isAuthenticated && (
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <span style={{ fontSize: "14px", color: "#4b5563" }}>{user?.name}</span>
          <button onClick={handleLogout} style={{ cursor: "pointer" }}>
            Logout
          </button>
        </div>
      )}
    </header>
  );
}
