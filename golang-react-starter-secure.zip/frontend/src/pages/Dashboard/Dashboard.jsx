import { useEffect, useState } from "react";
import { getUsers } from "../../services/userService";

export default function Dashboard() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    getUsers()
      .then((res) => setUsers(res.data || []))
      .catch(() => setError("Gagal memuat data user."));
  }, []);

  return (
    <div className="container" style={{ maxWidth: "600px" }}>
      <h2>Dashboard</h2>
      {error && <p className="error-text">{error}</p>}
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.name} — {user.email}
          </li>
        ))}
      </ul>
    </div>
  );
}
