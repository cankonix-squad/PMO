import { Navigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

export default function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  // Tunggu proses cek sesi (/me) selesai dulu, supaya tidak salah redirect
  // ke /login padahal sebenarnya cookie sesi masih valid.
  if (loading) {
    return <p style={{ textAlign: "center", marginTop: "80px" }}>Memuat...</p>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
