import axios from "axios";

// withCredentials: true -> browser otomatis kirim httpOnly cookie ke backend.
// Kita TIDAK menyimpan token di JavaScript sama sekali (tidak ada localStorage),
// supaya token tidak bisa dicuri lewat serangan XSS.
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8080/api",
  withCredentials: true,
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Sesi habis/invalid -> redirect ke login. AuthContext yang menangani
      // pembersihan state, di sini cukup redirect.
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default api;
