import api from "./api";

export async function login(email, password) {
  const response = await api.post("/auth/login", { email, password });
  return response.data;
}

export async function register(name, email, password) {
  const response = await api.post("/auth/register", { name, email, password });
  return response.data;
}

export async function logout() {
  const response = await api.post("/auth/logout");
  return response.data;
}

// Dipakai untuk cek status login saat aplikasi pertama kali dibuka,
// karena token tersimpan di httpOnly cookie yang tidak bisa dibaca JavaScript.
export async function getMe() {
  const response = await api.get("/auth/me");
  return response.data;
}
